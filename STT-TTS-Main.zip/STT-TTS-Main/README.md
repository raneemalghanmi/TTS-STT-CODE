# STT-TTS
Create IBM Watson service (STT,TTS )

STT -> Speech To Text

TTS -> Text To Speech

STT have :

* STT.mp4
 
* outext.txt

* transcribe.py

TTS have :

* TtS.py
 
* audio.mp3
 
* tex.txt

Live speech:

https://user-images.githubusercontent.com/71742682/125006532-3a2d9b80-e013-11eb-8fd1-b3b81dbec3a7.mp4
